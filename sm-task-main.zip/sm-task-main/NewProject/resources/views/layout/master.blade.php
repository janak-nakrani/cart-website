<!DOCTYPE html>
<html lang="en">
<head>
   @include('partial.header')
</head>
<body data-bs-spy="scroll" data-bs-target=".navbar">
    @include('layout.subheader')
    @yield('Content')
    @include('partial.script')
</body>
</html>