<header class="fixed-top py-3" id="navbar">
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand me-5">Shopping Page</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#carousel">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#CardMain">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#Reviews">Reviews</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#footer">footer</a>
                    </li>
                </ul>
            </div>
            <button type="button" class="my-auto me-5 btn position-relative rounded shadow" data-bs-toggle="offcanvas" data-bs-target="#YourCart">
                <i class="fa fa-shopping-cart"></i>
                <span class="position-absolute top-0 start-50 translate-middle badge text-dark" id="num">0</span>
            </button>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <i class="fa fa-bars"></i>
            </button>
        </div>
    </nav>
</header>
