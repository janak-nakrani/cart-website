@extends('layout.master')
@section('Content')
<div class="offcanvas offcanvas-end" tabindex="-1" id="YourCart">
    <div class="offcanvas-header border-bottom bg-secondary text-light">
        <h5 class="offcanvas-title">Shopping cart</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body position-relative bg-secondary bg-opacity-25">
        <div class="container" id="CartBody">
            <h2 class="display-1 fw-bold text-center text-light">Oops your cart is Empty</h2>
        </div>
    </div>
    <div class="offcanvas-footer border-top d-flex p-3 bg-secondary text-light text-center">
        <h6 class="me-auto" id="Qty">Quantity : 0 pcs</h6>
        <h6 class="ms-auto" id="total">Total : 0 Rs</h6>
    </div>
</div>
{{-- <div id="content">
    <div id="carousel" class="carousel Slider carousel-fade" data-bs-ride="carousel">
        <div class="carousel-indicators mb-5">
            <button type="button" data-bs-target="#carousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#carousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#carousel" data-bs-slide-to="2"></button>
        </div>
        <div class="carousel-inner text-center vh-100">
            <div class="carousel-item active">
                <img src="{{asset('img/images/slider1.jpg')}}">
                <!-- <div class="carousel-caption position-absolute top-50 start-50 translate-middle">
                    <h1>Heading</h1>
                    <p>Some Description About The photo</p>
                </div> -->
            </div>
            <div class="carousel-item">
                <img src="{{asset('img/images/slider2.avif')}}">
                <!-- <div class="carousel-caption position-absolute top-50 start-50 translate-middle">
                    <h1>Heading</h1>
                    <p>Some Description About The photo</p>
                </div> -->
            </div>
            <div class="carousel-item">
                <img src="{{asset('img/images/slider3.avif')}}">
                <!-- <div class="carousel-caption position-absolute top-50 start-50 translate-middle">
                    <h1>Heading</h1>
                    <p>Some Description About The photo</p>
                </div> -->
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carousel" data-bs-slide="prev">
            <span>
                <i class="fa fa-chevron-left" aria-hidden="true"></i>
            </span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carousel" data-bs-slide="next">
            <span>
                <i class="fa fa-chevron-right" aria-hidden="true"></i>
            </span>
        </button>
    </div>
</div> --}}
<div class="main bg-secondary bg-opacity-25">
    <div class="container py-3 pt-5">
        <div class="row justify-content-center my-3">
            <div class="col-lg-3 text-center bg-dark text-light">Filter : </div>
            <div class="col-lg-3 d-flex justify-content-evenly" id="btn-container">
            </div>
            <div class="col-lg-12 mb-5 mt-3">
                <div class="row row-cols-md-4 row-cols-1 g-3" id="CardMain"></div>
            </div>
            <hr>
            <div class="col-lg-4 text-center" id="Reviews">
                <h2>Customer Reviews</h2>
                <div class="card">
                    <div class="card-body">
                        <img src="" alt="" id="photos" class="card-img-top mb-2">
                        <h5 class="card-title" id="Title"></h5>
                        <p class="card-text" id="words"></p>
                        <button class="btn prev-btn">
                            <i class="fa fa-caret-left" aria-hidden="true"></i>
                        </button>
                        <button class="btn next-btn">
                            <i class="fa fa-caret-right" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 text-center">
                <h2>News</h2>
                <div class="btn-group d-flex">
                    <button type="button" class="btn btn-dark active">Left</button>
                    <button type="button" class="btn btn-dark">Middle</button>
                    <button type="button" class="btn btn-dark">Right</button>
                </div>
            </div>
        </div>
    </div>
</div>

<footer class="text-center bg-dark p-2" id="footer">
    <a class="text-decoration-none text-light">
        <h3>Thanks for visiting</h3>
    </a>
</footer>

<div class="fixed-bottom m-5 invisible" id="top-link">
    <a href="#" class="py-2 px-3 rounded-circle bg-danger text-light shadow">
        <i class="fa fa-arrow-up" aria-hidden="true"></i>
    </a>
</div>
@endsection
