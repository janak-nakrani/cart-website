function Submit() {
    let fname = document.getElementById("FName").value;
    let lname = document.getElementById("LName").value;
    let username = document.getElementById("UName").value;
    let email = document.getElementById("EMail").value;
    let address = document.getElementById("Address").value;
    let address2 = document.getElementById("Address1").value;
    let country = document.getElementById("Country").value;
    let state = document.getElementById("State").value;
    let zip = document.getElementById("Zip").value;
    let cardname = document.getElementById("CardName").value;
    let cardno = document.getElementById("CardNumber").value;

    let Details = `<div class='row justify-content-center'>
    <div class='col-10 p-3 border bg-light'>
    <h1 class='text-center'>Form Details</h1>
    <br>
    <dl>
    <dt>Name : </dt> <dd>${fname} ${lname}</dd>
    <dt>UserName : </dt> <dd>${username}</dd>
    <dt>Email : </dt> <dd>${email}</dd>
    <dt>Address : </dt> <dd>${address}, ${state}, ${country}, ${zip}</dd>
    <dt>Name on card : </dt> <dd>${cardname}</dd>
    <dt>Card No. : </dt> <dd>${cardno}</dd>
    </dl>
    </div>
    </div>`
    FinalDetails = document.getElementById("FinalDetails").innerHTML =
        Details;
}