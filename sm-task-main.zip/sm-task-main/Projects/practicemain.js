const shopping = [
  {
    name: "Pink tshirt",
    image: "images/Tshirt1.jpg",
    price: 749,
    category: "tshirt",
  },
  {
    name: "yellow shirt",
    image: "images/shirt4.jpg",
    price: 649,
    category: "shirt",
  },
  {
    name: "White tshirt",
    image: "images/Tshirt2.jpg",
    price: 649,
    category: "tshirt",
  },
  {
    name: "Yellow tshirt",
    image: "images/Tshirt3.jpg",
    price: 559,
    category: "tshirt",
  },
  {
    name: "Blue shirt",
    image: "images/shirt1.png",
    price: 899,
    category: "shirt",
  },
  {
    name: "Black tshirt",
    image: "images/Tshirt4.webp",
    price: 599,
    category: "tshirt",
  },
  {
    name: "black shirt",
    image: "images/shirt5.jpg",
    price: 599,
    category: "shirt",
  },
  {
    name: "Blue tshirt",
    image: "images/Tshirt5.jpg",
    price: 899,
    category: "tshirt",
  },
  {
    name: "Orange tshirt",
    image: "images/Tshirt6.jpg",
    price: 359,
    category: "tshirt",
  },
  {
    name: "Striped shirt",
    image: "images/shirt2.jpg",
    price: 799,
    category: "shirt",
  },
  {
    name: "Red tshirt",
    image: "images/Tshirt7.jpg",
    price: 299,
    category: "tshirt",
  },
  {
    name: "Olive tshirt",
    image: "images/Tshirt8.jpg",
    price: 599,
    category: "tshirt",
  },
  {
    name: "grey&blue shirt",
    image: "images/shirt3.jpg",
    price: 749,
    category: "shirt",
  },
  {
    name: "Grey tshirt",
    image: "images/Tshirt9.webp",
    price: 499,
    category: "tshirt",
  },
  {
    name: "Peach tshirt",
    image: "images/Tshirt10.jpg",
    price: 399,
    category: "tshirt",
  },
  {
    name: "grey shirt",
    image: "images/shirt6.jpg",
    price: 849,
    category: "shirt",
  },
  {
    name: "no shirt",
    image: "images/shirt6.jpg",
    price: 849,
    category: "pant",
  },
];

$(document).ready(function (item) {
  prepareBody(shopping);
  filterbuttons();
  
  // $('#shirt').click(function () {
  //     let filterdata = filterbyvlaue('shirt');
  //     prepareBody(filterdata)
  // })
  // $('#tshirt').click(function () {
  //     let filterdata1 = filterbyvlaue1('tshirt');
  //     prepareBody(filterdata1)
  // })

  // function filterbyvlaue(shirt) {
  //     let filteredBody = [];
  //     for (let i = 0; i < shopping.length; i++) {
  //         if (shopping[i]["category"] === 'shirt') {
  //             filteredBody = [...filteredBody, shopping[i]];
  //         }
  //     }
  //     return filteredBody;
  // }

  // function filterbyvlaue1(tshirt) {
  //     let filteredBody1 = [];
  //     for (let i = 0; i < shopping.length; i++) {
  //         if (shopping[i]["category"] === 'tshirt') {
  //             filteredBody1 = [...filteredBody1, shopping[i]];
  //         }
  //     }
  //     return filteredBody1;
  // }
});

function filterbuttons(){
    let categories = shopping.reduce(
        function (value, item) {
          if (!value.includes(item.category)) {
            value.push(item.category);
          }
          return value;
        },
        ["all"]
      );
    
      let categorybtns = categories
        .map(function (category) {
          return `<button type="button" class="filter-btn list-group-item list-group-item-action bg-dark text-light" data-id="${category}">${category}</button>`;
        })
        .join("");
    
      $(".btn-container").html(categorybtns);
    
      let filterBtns = document.querySelectorAll(".filter-btn");
    
      filterBtns.forEach(function (btn) {
        btn.addEventListener("click", function (e) {
          let category = e.currentTarget.dataset.id;
          const displayMenu = shopping.filter(function (shopping) {
            if (shopping.category === category) {
              return shopping;
            }
          });
          if (category === "all") {
            prepareBody(shopping);
          } else {
            prepareBody(displayMenu);
          }
        });
      });
}

function prepareBody(shopping) {
  let body = shopping.map(function (item) {
    return `<div class="col">
                    <div class="card shadow overflow-visible position-relative p-2 text-center">
                        <img class="card-img-top h-50 border rounded shadow" src="${item.image}" alt="...">
                        <div class="card-body">
                            <h4 class="text-title">${item.name}</h4>
                        </div>
                        <div class="card-footer d-flex">
                            <h4 class="card-text me-auto">${item.price} Rs</h4>
                            <button type="button" class="button btn" id="${item}">
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M8 7.5a.5.5 0 0 1 .5.5v1.5H10a.5.5 0 0 1 0 1H8.5V12a.5.5 0 0 1-1 0v-1.5H6a.5.5 0 0 1 0-1h1.5V8a.5.5 0 0 1 .5-.5z"/>
                                    <path d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1zm3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4h-3.5zM2 5h12v9a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5z"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                    </div>`;
  });
  body = body.join("");

  $("#CardMain").html(body);

  $(".button").click(function (event) {
    i = event.target.id;
    addtoCart(i);
  });
}

const cart = [];

function addtoCart(i) {
  let name = shopping[i]["name"];
  let images = shopping[i]["image"];
  let price = shopping[i]["price"];
  let Qtys = 1;
  let position = i;

  let keyofPosition = cart
    .map(function (e) {
      return e.position;
    })
    .indexOf(position);
  console.log(keyofPosition);

  if (keyofPosition != -1) {
    cart[keyofPosition]["price"] += shopping[i]["price"];
    cart[keyofPosition]["quantity"] += 1;
  } else {
    cartitem = {
      name: name,
      image: images,
      price: price,
      quantity: Qtys,
      position: position,
    };
    cart.push(cartitem);
  }
  prepareacarthtml();
}

function prepareacarthtml() {
  let carthtml = "";
  let num = 0;
  let Total = 0;
  let nos = 0;
  for (let n in cart) {
    num += 1;
    Total += cart[n]["price"];
    nos += 1;
    carthtml += `<div class="card mb-3 p-2 shadow-lg">
                <div class="row g-0">
                    <div class="col-4 text-center d-flex align-items-center bg-secondary bg-opacity-50">
                        <img src="${cart[n]["image"]}" class="img-fluid rounded-start border-end" alt="...">
                    </div>
                    <div class="col-8">
                        <div class="card-body bg-secondary bg-opacity-50">
                            <button type="button" class="cross btn-close position-absolute top-0 end-0" id="${n}">
                            </button>
                            <p><strong>Item : </strong>${cart[n]["name"]}</p>
                            <p><strong>Price : </strong>${cart[n]["price"]} Rs</p>
                            <p class="d-flex">
                            <strong>Qty : </strong>
                            <button class="remove btn btn-dark badge rounded-circle mx-3">-</button>${cart[n]["quantity"]}
                            <button class="add btn btn-dark badge rounded-circle ms-3">+</button>
                            </p>
                        </div>
                    </div>
                </div>
            </div>`;
  }
  $("#CartBody").html(carthtml);
  $("#num").html(num);
  $("#total").html("Total : " + Total + " Rs");
  $("#Qty").html("Total item : " + nos);

  $(".cross").click(function (event) {
    n = event.target.id;
    removecartitem(n);
  });

  let quant = cart[n]["quantity"];

  $(".remove").click(function (event) {
    n = event.target.id;
    if (quant == "1") {
      removecartitem(n);
    } else {
      quant -= 1;
    }
  });

  function removecartitem(n) {
    cart.splice($.inArray(cart[n], cart), 1);
    prepareacarthtml(cart);
  }

  $(".add").click(function (event) {
    n = event.target.id;
    addqunatity(n);
  });

  function addqunatity(n) {
    quant += 1;
  }
}

// $('#shirt').click(function () {
//     // $(document).html(filteredBody);
//     let filterdata = filterbyvlaue('shirt');
//     prepareBody(filterdata)
// })

// function filterbyvlaue(shirt) {
//     let filteredBody = [];
//     for (let i = 0; i < shopping.length; i++) {
//         if (shopping[i]["category"] === 'shirt') {
//             filteredBody = [...filteredBody, shopping[i]];
//         }
//     }
//     return filteredBody;
// }
