function changemode() {
    document.body.classList.toggle("dark-mode");
 }