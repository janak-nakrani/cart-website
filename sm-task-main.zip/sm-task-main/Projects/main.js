// main jquery function

$(document).ready(function () {
  prepareBody(shopping);
  Reviewcard();
  filterbuttons();

  $(window).scroll(function () {
    let scrollHeight = window.scrollY;
    let navHeight = navbar.getBoundingClientRect().height;
    if (scrollHeight > navHeight) {
      $("#navbar").addClass("bg-light", "shadow");
    } else {
      $("#navbar").removeClass("bg-light", "shadow");
    }
    if (scrollHeight > 500) {
      $("#top-link").removeClass("invisible");
    } else {
      $("#top-link").addClass("invisible");
    }
  });
});

// main jquery function end

// shopping items section

const shopping = [
  {
    name: "Pink tshirt",
    image: "images/Tshirt1.jpg",
    price: 749,
    category: "tshirt",
  },
  {
    name: "yellow shirt",
    image: "images/shirt4.jpg",
    price: 649,
    category: "shirt",
  },
  {
    name: "White tshirt",
    image: "images/Tshirt2.jpg",
    price: 649,
    category: "tshirt",
  },
  {
    name: "Yellow tshirt",
    image: "images/Tshirt3.jpg",
    price: 559,
    category: "tshirt",
  },
  {
    name: "Blue shirt",
    image: "images/shirt1.png",
    price: 899,
    category: "shirt",
  },
  {
    name: "Black tshirt",
    image: "images/Tshirt4.webp",
    price: 599,
    category: "tshirt",
  },
  {
    name: "black shirt",
    image: "images/shirt5.jpg",
    price: 599,
    category: "shirt",
  },
  {
    name: "Blue tshirt",
    image: "images/Tshirt5.jpg",
    price: 899,
    category: "tshirt",
  },
  {
    name: "Orange tshirt",
    image: "images/Tshirt6.jpg",
    price: 359,
    category: "tshirt",
  },
  {
    name: "Striped shirt",
    image: "images/shirt2.jpg",
    price: 799,
    category: "shirt",
  },
  {
    name: "Red tshirt",
    image: "images/Tshirt7.jpg",
    price: 299,
    category: "tshirt",
  },
  {
    name: "Olive tshirt",
    image: "images/Tshirt8.jpg",
    price: 599,
    category: "tshirt",
  },
  {
    name: "grey&blue shirt",
    image: "images/shirt3.jpg",
    price: 749,
    category: "shirt",
  },
  {
    name: "Grey tshirt",
    image: "images/Tshirt9.webp",
    price: 499,
    category: "tshirt",
  },
  {
    name: "Peach tshirt",
    image: "images/Tshirt10.jpg",
    price: 399,
    category: "tshirt",
  },
  {
    name: "grey shirt",
    image: "images/shirt6.jpg",
    price: 849,
    category: "shirt",
  },
];

function prepareBody(data) {
  body = "";
  for (let i = 0; i < data.length; i++) {
    body += `<div class="col p-2">
                    <div class="card bg-dark bg-opacity-25 text-center shadow">
                        <h4 class="card-header">${data[i]["name"]}</h4>
                            <div class="text-center">
                            <div class="card-image"> 
                                <img class="img-thumbnail w-75 mt-2 shadow" src="${data[i]["image"]}">
                            </div>
                            <h5 class="card-title mt-2" id="amount">Price : ${data[i]["price"]}</h5>
                            <button id="${i}" class="button btn btn-light mb-2 shadow fs-5 fw-bold px-5"><i class="fa fa-cart-plus me-3"></i>Add to cart</button>
                        </div>
                    </div>
                </div>`;
  }
  $("#CardMain").html(body);

  $(document).on("click", ".button", function (event) {
    index = event.currentTarget.id;
    addtoCart(index);
    $(this).html("Thanks");
  });
}

// shopping items section end

//filter buttons section

function filterbuttons() {
  let categories = shopping.reduce(
    function (value, item) {
      if (!value.includes(item.category)) {
        value.push(item.category);
      }
      return value;
    },
    ["all"]
  );

  let categorybtns = categories.map(function (category) {
    return `<button class="filter-btn btn btn-outline-dark" data-id="${category}">${category}</button>`;
  })
    .join("");

  $("#btn-container").html(categorybtns);

  let filterBtns = document.querySelectorAll(".filter-btn");

  filterBtns.forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      let category = e.currentTarget.dataset.id;
      const displayMenu = shopping.filter(function (shopping) {
        if (shopping.category === category) {
          return shopping;
        }
      });
      if (category === "all") {
        prepareBody(shopping);
      } else {
        prepareBody(displayMenu);
      }
    });
  });
}

//filter buttons section end

// customer review section

const Review = [
  {
    Name: "Customer_1",
    text: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus excepturi corporis",
    img: "images/womamimage.png",
  },
  {
    Name: "Customer_2",
    text: "voluptatibus, incidunt quibusdam deleniti sunt reiciendis natus corrupti.",
    img: "images/menimage.png",
  },
  {
    Name: "Customer_3",
    text: "obcaecati expedita explicabo illum totam, nesciunt deserunt autem culpa tempore",
    img: "images/womamimage.png",
  },
  {
    Name: "Customer_4",
    text: "vero ad suscipit id optio tempora corporis sunt aperiam vitae .",
    img: "images/menimage.png",
  },
  {
    Name: "Customer_5",
    text: "assumenda reprehenderit nobis eaque adipisci neque. Suscipit maiores nesciunt odio ducimus",
    img: "images/womamimage.png",
  },
];

let currentItem = 0;

function Reviewcard() {
  let iteam = Review[currentItem];
  $("#Title").html(iteam.Name);
  $("#words").html(iteam.text);
  $("#photos").attr("src", iteam.img);
}

$(".next-btn").click(function () {
  currentItem++;
  if (currentItem > Review.length - 1) {
    currentItem = 0;
  }
  Reviewcard();
});
$(".prev-btn").click(function () {
  currentItem--;
  if (currentItem < 0) {
    currentItem = Review.length - 1;
  }
  Reviewcard();
});

// customer review section end

// shopping cart section

const cart = [];

function addtoCart(i) {
  let name = shopping[i]["name"];
  let images = shopping[i]["image"];
  let price = shopping[i]["price"];
  let Qtys = 1;
  let position = i;

  let keyofPosition = cart
    .map(function (e) {
      return e.position;
    })
    .indexOf(position);

  if (keyofPosition != -1) {
    cart[keyofPosition]["price"] += shopping[i]["price"];
    cart[keyofPosition]["quantity"] += 1;
  } else {
    cartitem = {
      name: name,
      image: images,
      price: price,
      quantity: Qtys,
      position: position,
    };
    cart.push(cartitem);
  }
  prepareacarthtml();
}

function prepareacarthtml() {
  let carthtml = "";
  let num = 0;
  let Total = 0;
  let nos = 0;
  for (let n in cart) {
    num++;
    Total += cart[n]["price"];
    nos++;
    carthtml += `<div class="card mb-3 shadow-lg">
                <div class="row g-0">
                    <div class="col-4 text-center d-flex align-items-center">
                        <img src="${cart[n]["image"]}" class="img-fluid rounded-start border-end" alt="...">
                    </div>
                    <div class="col-8">
                        <div class="card-body">
                            <button type="button" class="cross btn-close position-absolute top-0 end-0" id="${n}">
                            </button>
                            <p><strong>Item : </strong>${cart[n]["name"]}</p>
                            <p><strong>Price : </strong>${cart[n]["price"]} Rs</p>
                            <p class="d-flex">
                            <strong>Qty : </strong>
                            <button class="remove btn"><i class="fa fa-minus-circle" aria-hidden="true"></i></button>${cart[n]["quantity"]}
                            <button class="add btn"><i class="fa fa-plus-circle" aria-hidden="true"></i></button>
                            </p>
                        </div>
                    </div>
                </div>
            </div>`;
  }
  $("#CartBody").html(carthtml);
  $("#num").html(num);
  $("#total").html("Total : " + Total + " Rs");
  $("#Qty").html("Total item : " + nos);

  $(".cross").click(function (event) {
    n = event.target.id;
    removecartitem(n);
  });

  function removecartitem(n) {
    cart.splice($.inArray(cart[n], cart), 1);
    prepareacarthtml(cart);
  }
}

// shopping cart section end

$('.tab-a').click(function () {
  $(".tab").removeClass('d-block').addClass('d-none');
  $(".tab[data-id='" + $(this).attr('data-id') + "']").removeClass('d-none').addClass("d-block");
  // $(".tab-a").removeClass('active');
  // $(this).parent().find(".tab-a").addClass('active');
});