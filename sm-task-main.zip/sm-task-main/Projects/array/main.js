const Employee = [
    ["JS", "Employee 1", "12000"],
    ["JQuery", "Employee 2", "13000"],
    ["Laravel", "Employee 3", "14000"],
    ["PHP", "Employee 4", "15000"],
    ["JQuery", "Employee 5", "16000"],
    ["PHP", "Employee 6", "17000"],
    ["Laravel", "Employee 7", "18000"],
    ["PHP", "Employee 8", "19000"],
    ["JS", "Employee 9", "20000"],
    ["Laravel", "Employee 10", "21000"],
    ["JS", "Employee 11", "22000"],
    ["PHP", "Employee 12", "23000"]
    ];

    function CreateBody(i){
        let body = "";
        for (let i = 0; i < Employee.length; i++) {i
            body += `<div class="col">
            <div class="card">
                <div class="card-body">
                    <span>Name : </span><h5 class="card-title">${Employee[i][1]}</h5>
                    <span>Salary : </span><h6 class="card-text">${Employee[i][2]}</h6>
                    <span>Language Known : </span><h5 class="card-title">${Employee[i][0]}</h5>
                    <div class="btn-container d-flex justify-content-evenly">
                    <button class="delete btn btn-danger" id="${i}">Delete</button><button class="edit btn btn-primary" id="${i}">Edit</button>
                    </div>
                </div>
            </div>
        </div>`
        }
        document.getElementById('cardbody').innerHTML = body;
    }

    document.getElementById('body').addEventListener( CreateBody());

    var dltbtns = document.querySelectorAll("delete");

    dltbtns.addEventListener("click", function(e){
        m = e.target.id;
        DeleteItem(m);
    })

    function DeleteItem(m) {
        Employee.splice(Employee[m], 1);
    };
    
