const shopping = [
    ["Pink tshirt", "images/Tshirt1.jpg", 600],
    ["White tshirt", "images/Tshirt2.jpg", 620],
    ["Yellow tshirt", "images/Tshirt3.jpg", 540],
    ["Black tshirt", "images/Tshirt4.webp", 870],
    ["BLue tshirt", "images/Tshirt5.jpg", 730],
    ["Orange tshirt", "images/Tshirt6.jpg", 580],
    ["Red tshirt", "images/Tshirt7.jpg", 760],
    ["Olive tshirt", "images/Tshirt8.jpg", 830],
    ["Grey tshirt", "images/Tshirt9.webp", 650],
    ["Peach tshirt", "images/Tshirt10.jpg", 900]
]

body = "";
for (let i = 0; i < shopping.length; i++) {
    body += `<div class="col p-2">
                <div class="card bg-dark text-light text-center">
                    <div class="card-header">${shopping[i][0]}</div>
                        <div class="text-center card-image card-image-hover-zoom"> 
                        <img class="img-thumbnail w-75" src="${shopping[i][1]}">
                        </div>
                    <div class="card-body">
                        <div class="card-title" id="amount">Price : ${shopping[i][2]}</div>
                        <button class="btn btn-primary p-2" onclick="addtoCart(${[i]})">add to cart</button>
                    </div>
                </div>
            </div>` ;
}

function initialize() {
    document.getElementById("CardMain").innerHTML = body;
}

const cart = [];

function addtoCart(i) {

    let name = shopping[i][0];
    let images = shopping[i][1];
    let price = shopping[i][2];
    let Qtys = 1;
    let position = i;

    // var index = Data.map(function(e) { return e.name; }).indexOf('Nick');
    let keyofPosition = cart.map(function(e) { return e.position; }).indexOf(position);
    console.log(keyofPosition);
    
    if(keyofPosition != -1) {
        cart[keyofPosition]["price"] += shopping[i][2];
        cart[keyofPosition]["quantity"] += 1;
    } else {
        cartitem = { "name": name, "image": images, "price": price, "quantity": Qtys, "position": position };
        cart.push(cartitem);
    }

    // Or
    // if(keyofPosition == -1) {
    //     cartitem = { "name": name, "image": images, "price": price, "quantity": Qtys, "position": position };
    //     cart.push(cartitem);
    // } else {
    //     cart[keyofPosition]["price"] += shopping[i][2];
    //     cart[keyofPosition]["quantity"] += 1;
    // }

    //if(cart.length > 0) {
        // for (let j = 0; j < cart.length; j++) {
        //     //alert(cart[j]["index"]);
        //     if(cart[j]["index"] == index) {
        //         cart[j]["price"] += shopping[i][2];
        //         cart[j]["quantity"] += 1;
        //         break;
        //     } else {
        //         cartitem = { "name": name, "image": images, "price": price, "quantity": Qtys, "index": index };
        //         cart.push(cartitem);
        //         break;
        //     }
        //     console.log("++++++++++");
        // }
    //} else {
        // cartitem = { "name": name, "image": images, "price": price, "quantity": Qtys, "index": index };
        // cart.push(cartitem);
    //}
    console.log(cart);
    
    prepareacarthtml(cart);
}


function prepareacarthtml(cart) {
    let carthtml = "";
    let num = 0;
    let Total = 0;
    let nos = 0;
    for (let n in cart) {
        num += 1;
        Total += cart[n]["price"];
        nos += 1;
        carthtml +=
            `<div class="card mb-3">
                <div class="row g-0">
                    <div class="col-4 text-center">
                        <img src="${cart[n]["image"]}" class="img-fluid rounded-start border-end" alt="...">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <button type="button" class="btn-close position-absolute top-0 end-0" onclick="removecartitem(${n})">
                            </button>
                            <p><strong>Item : </strong>${cart[n]["name"]}</p>
                            <p><strong>Price : </strong>${cart[n]["price"]} Rs</p>
                            <p><strong>Qty : </strong>${cart[n]["quantity"]} nos</p>
                        </div>
                    </div>
                </div>
            </div>`

    }
    document.getElementById("CartBody").innerHTML = carthtml;
    document.getElementById("num").innerHTML = num;
    document.getElementById("total").innerHTML = "Total : " + Total + " Rs";
    document.getElementById("Qty").innerHTML = "Total item : " + nos ;
}

function removecartitem(key) {
    cart.splice(key, 1)
    prepareacarthtml(cart)
}