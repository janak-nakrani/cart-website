displayTodo();

function createTodo() {
  let todo = document.getElementById("input").value;
  if (todo == "") {
    alert("Enter The Value in input box");
  } else {
    let count = Math.floor(Math.random() * 100);
    localStorage.setItem(count, todo);
    displayTodo();
    clearInput();
  }
}
function clearInput() {
  document.getElementById("input").value = "";
}

function displayTodo() {
  let html = "";
  if (localStorage.length <= 0) {
    html += ` <div class="col-lg-12  p-4  bg-shadow rounded-4">
      <div class="card mx-auto" style="width: 45rem;">
        
          <div class="card-body text-center">
         <strong>Make new todo list enter input in input field</strong>
          </div>
        </div>
    </div>`;
  }
  for (i = 0; i < localStorage.length; i++) {
    let key = localStorage.key(i);
    // console.log(`${key}: ${localStorage.getItem(key)}`);
    html += ` <div class="col-lg-4  p-4  bg-shadow rounded-4">
      <div class="card mx-auto" style="width: 18rem;">
        
          <div class="card-body">
            <h5 class="card-title">Todo ${key}</h5>
            <p class="card-text">${localStorage.getItem(key)}</p>
            <a href="#" class="btn btn-info btn-sm" onclick="editTodo(${key})">Edit</a>
            <a href="#" class="btn btn-danger btn-sm" onclick="deleteTodo(${key})">Delete</a>
          </div>
        </div>
    </div>`;
  }
  document.getElementById("card").innerHTML = html;
}

function deleteTodo(key) {
  iziToast.show({
    theme: "light",
    icon: "icon-person",
    title: `Are You sure want to delete! ${key} Todo`,
    // message: `Are You sure want to delete! ${key} Todo`,
    color: "red", // blue,
    position: "center", // bottomRight, bottomLeft, topRight, topLeft, topCenter, bottomCenter
    progressBarColor: "rgb(0, 255, 184)",
    buttons: [
      [
        "<button>Delete</button>",
        function (instance, toast) {
          localStorage.removeItem(key);
          displayTodo();
          instance.hide(
            {
              transitionOut: "fadeOutUp",
              onClosing: function (instance, toast, closedBy) {
                console.info("closedBy: " + closedBy); // The return will be: 'closedBy: buttonName'
              },
            },
            toast,
            "buttonName"
          );
        },
        true,
      ], // true to focus
      [
        "<button>Close</button>",
        function (instance, toast) {
          instance.hide(
            {
              transitionOut: "fadeOutUp",
              onClosing: function (instance, toast, closedBy) {
                console.info("closedBy: " + closedBy); // The return will be: 'closedBy: buttonName'
              },
            },
            toast,
            "buttonName"
          );
        },
      ],
    ],
    onOpening: function (instance, toast) {
      console.info("callback abriu!");
    },
    onClosing: function (instance, toast, closedBy) {
      console.info("closedBy: " + closedBy); // tells if it was closed by 'drag' or 'button'
    },
  });
  // localStorage.removeItem(key);
  // displayTodo();
}

function editTodo(key) {

  document.getElementById("addtodo").style.display = "none";
  let edittodo = localStorage.getItem(key);
  document.getElementById("input").value = edittodo;
  document.getElementById("title").value = key;

  document.getElementById("edittodo").style.display = "inline";
  document.getElementById("cancel").style.display = "inline";

}

function edit() {
  let inp = document.getElementById("input").value; 
  let key = document.getElementById("title").value; 
   localStorage.setItem(key,inp);
   document.getElementById("edittodo").style.display = "none";
  document.getElementById("cancel").style.display = "none";
  clearInput(); 
  displayTodo();
  iziToast.success({
   title: 'Success',
   message: 'Todo Edit successfully !',
});
  document.getElementById("addtodo").style.display = "inline";

}

function cancel() {
  location.reload();
}
